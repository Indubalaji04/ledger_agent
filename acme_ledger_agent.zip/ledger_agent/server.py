import os, re, json, time, math
from datetime import datetime
from urllib.parse import urljoin, urlparse
import requests
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

EMAIL = '24f1002317@ds.study.iitm.ac.in'
QUIZ_SIGN = 'VPwnv4ZvJzNmvtllr%2Btz4TSKbKpY60zzQkDEdeDpF4JH12HVOIvinlfljNRLyzkqqVxtDN4SpA1WIaTsa48voWA%2BTa6CzCWDNCAxE1N8rI1Ysht5%2Bcp7uHEEUZkGvdK5SuxuvMBXFo3WRSyuTrTyT0NKIuWoWj1CGHbXbApK8alRu5fWV1dfKAzHkz4b5RMZwcsZ7ew7CwiGgo1BPhwfqOfDjDhyY8QURepSyuabmuoI9DaffvS9yKvGvuog806NbtLK%2B0TrA9CF1rRJ3HirG3kYnpuCU5fO2WV6XXPkk2O3RqPdPdVZSKGgkvQhu9EWacYcOSkJ94UCQ4hokE3mKQ%3D%3D'
ROOT = f'https://exam.sanand.workers.dev/questionData?email={EMAIL.replace("@", "%40").replace(".", "%2E")}&quizSign={QUIZ_SIGN}&questionId=q-ledger-agent-server&path=/'
app = FastAPI(title='Acme Appliances Ledger Agent')

class Question(BaseModel):
    question: str

SESSION = requests.Session()
SESSION.headers.update({'User-Agent':'AcmeLedgerAgent/1.0','Accept':'application/json'})
CACHE = {'at': 0, 'records': [], 'raw': None}


def fetch_json(url):
    try:
        r = SESSION.get(url, timeout=5)
        r.raise_for_status()
        return r.json()
    except Exception:
        return None


def walk_json(obj, out, seen_ids):
    """Extract likely ledger records from nested JSON without assuming undocumented schema."""
    if isinstance(obj, list):
        for x in obj: walk_json(x, out, seen_ids)
        return
    if not isinstance(obj, dict): return
    # Each object with multiple scalar fields is a candidate record.
    scalars = {str(k).lower(): v for k,v in obj.items() if isinstance(v,(str,int,float,bool)) or v is None}
    keys = set(scalars)
    signal = any(any(t in k for t in ('order','amount','total','price','revenue','refund','product','customer','region','date','status','quantity','sku')) for k in keys)
    if signal and len(scalars) >= 2:
        try: sig = json.dumps(obj, sort_keys=True, default=str)
        except Exception: sig = repr(obj)
        if sig not in seen_ids:
            seen_ids.add(sig); out.append(obj)
    for v in obj.values():
        if isinstance(v,(dict,list)): walk_json(v,out,seen_ids)


def discover():
    now = time.time()
    if CACHE['records'] and now - CACHE['at'] < 60: return CACHE['records']
    records, seen = [], set()
    queue, visited = [ROOT], set()
    # Follow same-origin API links and common pagination pointers; bound work for latency.
    origin = urlparse(ROOT).netloc
    while queue and len(visited) < 35:
        url = queue.pop(0)
        if url in visited: continue
        visited.add(url)
        data = fetch_json(url)
        if data is None: continue
        walk_json(data, records, seen)
        links = []
        def find_links(x):
            if isinstance(x, dict):
                for k,v in x.items():
                    if isinstance(v,str) and (k.lower() in ('href','url','next','nextpage','next_page','self','orders','products','customers','refunds','ledger','api') or v.startswith('/')):
                        if v.startswith('/') or v.startswith('http'):
                            links.append(v)
                    elif isinstance(v,(dict,list)): find_links(v)
            elif isinstance(x,list):
                for v in x: find_links(v)
        find_links(data)
        for link in links:
            full = urljoin(url, link)
            if urlparse(full).netloc == origin and full not in visited and full not in queue:
                queue.append(full)
        # Common API styles: next-page cursors and endpoints exposed in root data.
        if isinstance(data,dict):
            for k in ('next','nextPage','next_page','next_url'):
                v=data.get(k)
                if isinstance(v,str):
                    full=urljoin(url,v)
                    if urlparse(full).netloc==origin and full not in visited and full not in queue: queue.append(full)
    CACHE.update(at=now, records=records, raw=True)
    return records


def norm(s): return re.sub(r'[^a-z0-9]+',' ',str(s).lower()).strip()
def val(record, names):
    for k,v in record.items():
        kl=norm(k)
        if any(n in kl for n in names) and v is not None: return v
    return None

def parse_months(q):
    ql=q.lower()
    months={'january':1,'jan':1,'february':2,'feb':2,'march':3,'mar':3,'april':4,'apr':4,'may':5,'june':6,'jun':6,'july':7,'jul':7,'august':8,'aug':8,'september':9,'sep':9,'sept':9,'october':10,'oct':10,'november':11,'nov':11,'december':12,'dec':12}
    for m,n in months.items():
        if re.search(r'\b'+m+r'\b',ql):
            y=re.search(r'\b(20\d{2})\b',ql)
            return (int(y.group(1)) if y else None,n)
    y=re.search(r'\b(20\d{2})[-/](\d{1,2})\b',ql)
    if y:return int(y.group(1)),int(y.group(2))
    return None,None

def answer_question(question, records):
    q=question.strip(); ql=q.lower()
    if not records: return 'I could not retrieve ledger records from the API.'
    # Determine common filters based on the actual field values and question terms.
    filtered=[]
    region_match=re.search(r'\b(?:in|from|for)\s+(?:the\s+)?([A-Za-z][A-Za-z -]+?)\s+region\b',q,re.I)
    region=region_match.group(1).strip() if region_match else None
    year, month=parse_months(q)
    # Dates, regions, products, customer names are inferred from records.
    for r in records:
        date=val(r,['date','created at','order date','timestamp'])
        if year or month:
            if not date: continue
            ds=str(date)
            try:
                if year and not re.search(r'\b'+str(year)+r'\b',ds):
                    # ISO dates contain year as a prefix
                    if not ds.startswith(str(year)): continue
                if month:
                    m=re.search(r'[-/](\d{1,2})(?:[-/]|$)',ds)
                    # ISO YYYY-MM-DD
                    if re.match(r'^\d{4}-\d{2}',ds): dm=int(ds[5:7])
                    elif m: dm=int(m.group(1))
                    else:
                        try: dm=datetime.fromisoformat(ds.replace('Z','+00:00')).month
                        except: dm=None
                    if dm != month: continue
            except Exception: continue
        if region:
            rv=val(r,['region','territory','sales area'])
            if rv is None or norm(region) not in norm(rv): continue
        # Customer/product named filters: match any non-generic tokens against record values.
        filtered.append(r)
    if not filtered: filtered=records if not (year or month or region) else []
    if not filtered: return 0 if any(x in ql for x in ('revenue','refund','total','how many','count')) else 'No matching records found.'

    # Filter products or customers mentioned explicitly, using field values.
    for kind, keys in [('product',['product','item','sku']),('customer',['customer','client','buyer'])]:
        target_field=val(filtered[0],keys)
        if target_field is not None:
            candidates={str(val(r,keys)) for r in records if val(r,keys) is not None}
            matches=[c for c in candidates if c.lower() in ql]
            if matches: filtered=[r for r in filtered if str(val(r,keys)) in matches]

    # Choose measure and aggregate.
    is_count=any(w in ql for w in ('how many','count of','number of orders','number of customers'))
    refund_q='refund' in ql
    if is_count:
        # Prefer order identifier for distinct order counts.
        ids=[val(r,['order id','order_id','order number','order']) for r in filtered]
        ids=[str(x) for x in ids if x is not None]
        return len(set(ids)) if ids else len(filtered)
    if any(w in ql for w in ('which product','top product','best-selling','bestselling','most popular')):
        counts={}
        for r in filtered:
            p=val(r,['product','item','sku'])
            if p is not None: counts[str(p)]=counts.get(str(p),0)+float(val(r,['quantity','units']) or 1)
        if counts:return max(counts,key=counts.get)
    amount_fields = ['refund amount','refunded amount','refund total'] if refund_q else ['revenue','order total','total amount','amount','line total','subtotal','price']
    nums=[]
    for r in filtered:
        amount=val(r,amount_fields)
        if amount is None and not refund_q:
            price=val(r,['unit price','price']); qty=val(r,['quantity','units'])
            if price is not None:
                try: amount=float(price)*float(qty or 1)
                except: amount=None
        try:
            if amount is not None: nums.append(float(str(amount).replace('$','').replace(',','')))
        except: pass
    if nums:
        total=round(sum(nums)+1e-9,2)
        return total
    # Useful fallback: return a field value for direct questions.
    if any(w in ql for w in ('which','what is','name')):
        for r in filtered:
            p=val(r,['product','customer','region','status'])
            if p is not None:return p
    return {'matching_records':len(filtered)}

@app.get('/')
def health(): return {'ok':True,'service':'acme-ledger-agent'}

@app.post('/')
def query(body: Question):
    try:
        records=discover()
        answer=answer_question(body.question,records)
        return {'answer':answer}
    except Exception as e:
        raise HTTPException(status_code=500, detail='Unable to answer question')

@app.post('/ask')
def ask(body: Question): return query(body)
