# Acme Appliances Ledger Agent

A small FastAPI service with `POST /` and `POST /ask` accepting `{"question":"..."}` and returning `{"answer": ...}`. It discovers JSON records and same-origin links from the challenge API, then applies basic natural-language filters and aggregations.

## Deploy
1. Upload `server.py`, `requirements.txt`, and `render.yaml` to a GitHub repository.
2. On Render, create a Web Service from the repo. Render can use `render.yaml` automatically.
3. Wait for deployment and use the public HTTPS service URL (root URL, no `/mcp`) as the exam endpoint.
4. Test with `curl -X POST https://YOUR-SERVICE.onrender.com/ -H "Content-Type: application/json" -d '{"question":"What was the total revenue in USD from the North region in March 2026?"}'`.

The hosted service must be able to access `exam.sanand.workers.dev`. This environment could not access that API during packaging, so the crawler and field mappings are intentionally schema-adaptive but should be validated against the live data before submitting.
